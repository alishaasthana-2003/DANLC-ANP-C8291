#Q2. Write a program to input length and breath of a triangle and print its Area?
l=int(input("Enter the number"))
b=int(input("Enter the number"))
Area=0.5*l*b
print("Area of Triangle is:", Area)