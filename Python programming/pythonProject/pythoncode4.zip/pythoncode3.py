#Q3. Write a program to input total marks of a student and print students' percentage.
marks=int(input("Enter marks of student"))
total_marks=int(input("Enter total marks of student"))
percentage=marks/total_marks*100
print("The student's percentage is:",percentage)
