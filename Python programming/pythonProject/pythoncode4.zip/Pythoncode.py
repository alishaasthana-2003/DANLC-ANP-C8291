a=int(input("Enter the number"))
b=int(input("Enter the number"))
add= a+b
subtract = a-b
multiplication= a*b
division= a/b
modulus= a%b
print("add:",add)
print("subtaction:",subtract)
print("multiplication:",multiplication)
print("division:",division)
print("modulus:",modulus)




