#Q4. Write a program to input basic salary of an employee and print bonus(10% of Basic salary).
Basic_salary=int(input("Enter the basic salary of Employee"))
Bonus=0.1*Basic_salary
print("Bonus is:", Bonus)